$(document).ready(function() {
    $('#example').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});
$(document).ready(function() {
    $('#example2').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});
$(document).ready(function() {
    $('#podrska_naslovna').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});
$(document).ready(function() {
    $('#vpn_zahtjev').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});
$(document).ready(function() {
    $('#tvrtke').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});
$(document).ready(function() {
    $('#tvrtke1').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});
$(document).ready(function() {
    $('#tvrtke2').DataTable({
        language: {
            searchPlaceholder: 'Pretraga',
            sSearch: '',
            sLengthMenu: 'Prikaži: _MENU_',
            sLength: 'dataTables_length',
            oPaginate: {
                sFirst: '<i class="material-icons">chevron_left</i>',
                sPrevious: '<i class="material-icons">chevron_left</i>',
                sNext: '<i class="material-icons">chevron_right</i>',
                sLast: '<i class="material-icons">chevron_right</i>' 
        }
        }
    });
    $('.dataTables_length select').addClass('browser-default');
});