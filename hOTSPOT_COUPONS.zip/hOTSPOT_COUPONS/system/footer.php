<?php
if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) exit('No direct access allowed.');

/*****************************************************************
                     Made by ONLINE TELEKOM
			    - all scripts is on ENG language
				- info@online-telekom.com
				- www.online-telekom.com
*****************************************************************/

?>
            <div class="page-footer">
                <div class="footer-grid container">
                    <div class="footer-l white">&nbsp;</div>
                    <div class="footer-grid-l white">
                    </div>
                    <div class="footer-r white">&nbsp;</div>
                    <div class="footer-grid-r white">
                        <a class="footer-text" href="https://online-telekom.com" target="_blank">
                            <i class="material-icons arrow-r">arrow_forward</i>
                            <span class="direction">{CODE}+{MAINTENANCE}</span>
                            <div>
                                ONLINE TELEKOM
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="left-sidebar-hover"></div>

		<noscript>
		<div class="noscriptmsg" style=
		"display: block;top: 0; color: white; position: fixed; z-index: 9999; background: #ab0000; font-size: 40px; text-align: center; width: 100%;height: 100%;">
		<center><img style="width:25%;" src="<?php echo WWW; ?>includes/themes/<?php echo THEME_NAME;?>/img/noscript.png"></img></center>
		<br>Molimo vas aktivirajte javaskriptu u Vašem pregledniku.</br>
		<hr style="width:80%;">
		<p><a style="font-size:20px; color:white;" href="http://enable-javascript.com/hr/" target="_blank">Pogledaj kako uključiti javascriptu.</a></p>
		</div>
		</noscript>
        
		<script src="assets/plugins/datatables/js/jquery.dataTables.min.js"></script>  
        <script src="assets/js/pages/table-data.js"></script>
        
        <script src="assets/plugins/materialize/js/materialize.min.js"></script>
        <script src="assets/plugins/material-preloader/js/materialPreloader.min.js"></script>
       
      
        <script src="assets/js/alpha.min.js"></script>
        <script src="assets/js/istracom.js"></script>
        <script src="assets/js/pages/form-wizard.js"></script>  
     
		
   
     

		
         <!-- Javascripts -->
     

		
    </body>
</html>